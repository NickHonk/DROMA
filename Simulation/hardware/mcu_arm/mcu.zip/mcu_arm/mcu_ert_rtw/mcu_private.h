//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: mcu_private.h
//
// Code generated for Simulink model 'mcu'.
//
// Model version                  : 1.284
// Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
// C/C++ source code generated on : Tue Jul 14 13:27:49 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef mcu_private_h_
#define mcu_private_h_
#include "rtwtypes.h"
#include "mcu_types.h"
#endif                                 // mcu_private_h_

//
// File trailer for generated code.
//
// [EOF]
//
